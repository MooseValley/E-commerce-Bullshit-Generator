# E-commerce Bullshit Generator

Simple command-line tool to generate buzzword "word salad" non-sense.

i.e. The meaningless garbage cryptocurrency, blockchain, NFT, and Web 3.0 "projects" always spout.


### Uses the JavaScript arrays from the Corporate B.S. Generator here:
* https://dack.com/web/bullshit.html
* https://www.atrixnet.com/bs-generator.html
* http://emptybottle.org/bullshit/


### Sample Output:
<pre>
appropriately strategize fully tested methods of empowerment
completely right-shore frictionless human capital
globally re-engineer clicks-and-mortar alignments
dramatically engage extensible e-tailers
dramatically transition end-to-end markets
continually reintermediate market positioning e-markets
energistically benchmark holistic e-markets
intrinsically recaptiualize enabled services
uniquely morph quality mindshare
distinctively productivate integrated ROI
</pre>

### Moose OMalley
Moose's Software Valley
<br>https://moosevalley.github.io/
